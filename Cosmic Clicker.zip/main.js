// Cosmic Clicker - Main Game Logic
class CosmicClicker {
    constructor() {
        this.energy = 0;
        this.totalEnergy = 0;
        this.clickPower = 1;
        this.pulsars = 0;
        this.quasars = 0;
        this.nebulas = 0;
        this.pulsarRate = 1;
        this.quasarRate = 5;
        this.nebulaRate = 20;
        this.pulsarBaseCost = 10;
        this.quasarBaseCost = 100;
        this.nebulaBaseCost = 500;
        this.clickBaseCost = 50;
        this.achievements = [];
        this.floatingNumbers = [];
        
        this.loadGame();
        this.setupEventListeners();
        this.startAutoGeneration();
        this.updateDisplay();
        this.checkAchievements();
    }

    setupEventListeners() {
        // Clicker sphere
        const sphere = document.getElementById('clicker-sphere');
        sphere.addEventListener('click', (e) => this.handleClick(e));
        
        // Prevent context menu on sphere
        sphere.addEventListener('contextmenu', (e) => e.preventDefault());
    }

    handleClick(event) {
        // Add energy
        this.energy += this.clickPower;
        this.totalEnergy += this.clickPower;
        
        // Create click ripple effect
        this.createClickRipple(event);
        
        // Create floating number
        this.createFloatingNumber(event, this.clickPower);
        
        // Particle burst effect
        this.createParticleBurst(event);
        
        // Update display
        this.updateDisplay();
        
        // Check achievements
        this.checkAchievements();
        
        // Save game
        this.saveGame();
    }

    createClickRipple(event) {
        const ripple = document.createElement('div');
        ripple.className = 'click-ripple';
        
        const rect = event.target.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        
        event.target.appendChild(ripple);
        
        setTimeout(() => ripple.remove(), 600);
    }

    createFloatingNumber(event, value) {
        const floatingNumber = document.createElement('div');
        floatingNumber.className = 'floating-number';
        floatingNumber.textContent = '+' + this.formatNumber(value);
        
        const rect = event.target.getBoundingClientRect();
        floatingNumber.style.left = (event.clientX - rect.left) + 'px';
        floatingNumber.style.top = (event.clientY - rect.top) + 'px';
        
        document.getElementById('particle-burst').appendChild(floatingNumber);
        
        // Animate floating number
        anime({
            targets: floatingNumber,
            translateY: -50,
            opacity: [1, 0],
            duration: 1000,
            easing: 'easeOutQuad',
            complete: () => floatingNumber.remove()
        });
    }

    createParticleBurst(event) {
        const burstContainer = document.getElementById('particle-burst');
        const rect = event.target.getBoundingClientRect();
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        // Create multiple particles
        for (let i = 0; i < 12; i++) {
            const particle = document.createElement('div');
            particle.style.position = 'absolute';
            particle.style.width = '4px';
            particle.style.height = '4px';
            particle.style.backgroundColor = '#00D4FF';
            particle.style.borderRadius = '50%';
            particle.style.left = centerX + 'px';
            particle.style.top = centerY + 'px';
            particle.style.pointerEvents = 'none';
            
            burstContainer.appendChild(particle);
            
            // Animate particle
            const angle = (i / 12) * Math.PI * 2;
            const distance = 100 + Math.random() * 50;
            
            anime({
                targets: particle,
                translateX: Math.cos(angle) * distance,
                translateY: Math.sin(angle) * distance,
                scale: [1, 0],
                opacity: [1, 0],
                duration: 800,
                easing: 'easeOutQuad',
                complete: () => particle.remove()
            });
        }
    }

    buyPulsar() {
        const cost = this.getPulsarCost();
        if (this.energy >= cost) {
            this.energy -= cost;
            this.pulsars++;
            this.updateDisplay();
            this.checkAchievements();
            this.saveGame();
            
            // Visual feedback
            this.flashUpgrade('pulsar-card');
        }
    }

    buyQuasar() {
        const cost = this.getQuasarCost();
        if (this.energy >= cost) {
            this.energy -= cost;
            this.quasars++;
            this.updateDisplay();
            this.checkAchievements();
            this.saveGame();
            
            // Visual feedback
            this.flashUpgrade('quasar-card');
        }
    }

    buyNebula() {
        const cost = this.getNebulaCost();
        if (this.energy >= cost) {
            this.energy -= cost;
            this.nebulas++;
            this.updateDisplay();
            this.checkAchievements();
            this.saveGame();
            
            // Visual feedback
            this.flashUpgrade('nebula-card');
        }
    }

    upgradeClick() {
        const cost = this.getClickCost();
        if (this.energy >= cost) {
            this.energy -= cost;
            this.clickPower++;
            this.updateDisplay();
            this.checkAchievements();
            this.saveGame();
            
            // Visual feedback
            this.flashUpgrade('click-card');
        }
    }

    flashUpgrade(cardId) {
        const card = document.getElementById(cardId);
        card.style.boxShadow = '0 0 30px rgba(0, 212, 255, 0.8)';
        setTimeout(() => {
            card.style.boxShadow = '';
        }, 300);
    }

    getPulsarCost() {
        return Math.floor(this.pulsarBaseCost * Math.pow(1.15, this.pulsars));
    }

    getQuasarCost() {
        return Math.floor(this.quasarBaseCost * Math.pow(1.2, this.quasars));
    }

    getNebulaCost() {
        return Math.floor(this.nebulaBaseCost * Math.pow(1.25, this.nebulas));
    }

    getClickCost() {
        return Math.floor(this.clickBaseCost * Math.pow(2, this.clickPower - 1));
    }

    startAutoGeneration() {
        setInterval(() => {
            const autoEnergy = (this.pulsars * this.pulsarRate) + 
                              (this.quasars * this.quasarRate) + 
                              (this.nebulas * this.nebulaRate);
            
            if (autoEnergy > 0) {
                this.energy += autoEnergy;
                this.totalEnergy += autoEnergy;
                this.updateDisplay();
                this.checkAchievements();
            }
        }, 1000);
    }

    updateDisplay() {
        // Energy display
        document.getElementById('energy-display').textContent = this.formatNumber(Math.floor(this.energy));
        
        // Per click and per second
        const perSecond = (this.pulsars * this.pulsarRate) + 
                         (this.quasars * this.quasarRate) + 
                         (this.nebulas * this.nebulaRate);
        
        document.getElementById('per-click').textContent = this.formatNumber(this.clickPower);
        document.getElementById('per-second').textContent = this.formatNumber(perSecond);
        
        // Pulsar display
        document.getElementById('pulsar-count').textContent = this.formatNumber(this.pulsars);
        document.getElementById('pulsar-rate').textContent = this.formatNumber(this.pulsarRate);
        document.getElementById('pulsar-cost').textContent = this.formatNumber(this.getPulsarCost());
        
        // Quasar display
        document.getElementById('quasar-count').textContent = this.formatNumber(this.quasars);
        document.getElementById('quasar-rate').textContent = this.formatNumber(this.quasarRate);
        document.getElementById('quasar-cost').textContent = this.formatNumber(this.getQuasarCost());
        
        // Nebula display
        document.getElementById('nebula-count').textContent = this.formatNumber(this.nebulas);
        document.getElementById('nebula-rate').textContent = this.formatNumber(this.nebulaRate);
        document.getElementById('nebula-cost').textContent = this.formatNumber(this.getNebulaCost());
        
        // Click upgrade display
        document.getElementById('click-level').textContent = this.formatNumber(this.clickPower);
        document.getElementById('click-increase').textContent = this.formatNumber(this.clickPower);
        document.getElementById('click-cost').textContent = this.formatNumber(this.getClickCost());
        
        // Update button states
        this.updateButtonStates();
    }

    updateButtonStates() {
        // Pulsar button
        const pulsarButton = document.getElementById('buy-pulsar');
        const pulsarCost = this.getPulsarCost();
        pulsarButton.disabled = this.energy < pulsarCost;
        pulsarButton.style.opacity = this.energy < pulsarCost ? '0.5' : '1';
        
        // Quasar button
        const quasarButton = document.getElementById('buy-quasar');
        const quasarCost = this.getQuasarCost();
        quasarButton.disabled = this.energy < quasarCost;
        quasarButton.style.opacity = this.energy < quasarCost ? '0.5' : '1';
        
        // Nebula button
        const nebulaButton = document.getElementById('buy-nebula');
        const nebulaCost = this.getNebulaCost();
        nebulaButton.disabled = this.energy < nebulaCost;
        nebulaButton.style.opacity = this.energy < nebulaCost ? '0.5' : '1';
        
        // Click upgrade button
        const clickButton = document.getElementById('upgrade-click');
        const clickCost = this.getClickCost();
        clickButton.disabled = this.energy < clickCost;
        clickButton.style.opacity = this.energy < clickCost ? '0.5' : '1';
    }

    checkAchievements() {
        const achievements = [
            { id: 'first_click', name: 'First Click', description: 'Click the cosmic sphere for the first time', condition: () => this.totalEnergy >= 1 },
            { id: 'hundred_energy', name: 'Century Club', description: 'Generate 100 total energy', condition: () => this.totalEnergy >= 100 },
            { id: 'thousand_energy', name: 'Energy Master', description: 'Generate 1,000 total energy', condition: () => this.totalEnergy >= 1000 },
            { id: 'first_pulsar', name: 'Pulsar Power', description: 'Buy your first pulsar', condition: () => this.pulsars >= 1 },
            { id: 'ten_pulsars', name: 'Pulsar Array', description: 'Own 10 pulsars', condition: () => this.pulsars >= 10 },
            { id: 'first_quasar', name: 'Quasar Queen', description: 'Buy your first quasar', condition: () => this.quasars >= 1 },
            { id: 'first_nebula', name: 'Nebula Lord', description: 'Buy your first nebula', condition: () => this.nebulas >= 1 },
            { id: 'click_master', name: 'Click Master', description: 'Reach 10 click power', condition: () => this.clickPower >= 10 },
            { id: 'million_energy', name: 'Cosmic Emperor', description: 'Generate 1,000,000 total energy', condition: () => this.totalEnergy >= 1000000 }
        ];

        for (let achievement of achievements) {
            if (!this.achievements.includes(achievement.id) && achievement.condition()) {
                this.achievements.push(achievement.id);
                this.showAchievement(achievement.name, achievement.description);
                this.saveGame();
            }
        }
    }

    showAchievement(name, description) {
        const banner = document.getElementById('achievement-banner');
        const text = document.getElementById('achievement-text');
        
        text.textContent = name;
        
        // Animate banner
        anime({
            targets: banner,
            translateX: ['100%', '0%'],
            duration: 500,
            easing: 'easeOutQuad'
        });
        
        // Hide banner after 3 seconds
        setTimeout(() => {
            anime({
                targets: banner,
                translateX: ['0%', '100%'],
                duration: 500,
                easing: 'easeInQuad'
            });
        }, 3000);
    }

    formatNumber(num) {
        if (num < 1000) return num.toString();
        if (num < 1000000) return (num / 1000).toFixed(1) + 'K';
        if (num < 1000000000) return (num / 1000000).toFixed(1) + 'M';
        if (num < 1000000000000) return (num / 1000000000).toFixed(1) + 'B';
        return (num / 1000000000000).toFixed(1) + 'T';
    }

    saveGame() {
        const gameData = {
            energy: this.energy,
            totalEnergy: this.totalEnergy,
            clickPower: this.clickPower,
            pulsars: this.pulsars,
            quasars: this.quasars,
            nebulas: this.nebulas,
            achievements: this.achievements,
            timestamp: Date.now()
        };
        
        localStorage.setItem('cosmicClicker', JSON.stringify(gameData));
    }

    loadGame() {
        const savedData = localStorage.getItem('cosmicClicker');
        if (savedData) {
            try {
                const gameData = JSON.parse(savedData);
                this.energy = gameData.energy || 0;
                this.totalEnergy = gameData.totalEnergy || 0;
                this.clickPower = gameData.clickPower || 1;
                this.pulsars = gameData.pulsars || 0;
                this.quasars = gameData.quasars || 0;
                this.nebulas = gameData.nebulas || 0;
                this.achievements = gameData.achievements || [];
            } catch (error) {
                console.log('Error loading game data:', error);
            }
        }
    }
}

// Global game instance
let game;

// Global functions for button clicks
function buyPulsar() {
    game.buyPulsar();
}

function buyQuasar() {
    game.buyQuasar();
}

function buyNebula() {
    game.buyNebula();
}

function upgradeClick() {
    game.upgradeClick();
}

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    game = new CosmicClicker();
    
    // Add some entrance animations
    anime({
        targets: '.upgrade-card',
        translateY: [50, 0],
        opacity: [0, 1],
        delay: anime.stagger(100),
        duration: 800,
        easing: 'easeOutQuad'
    });
    
    anime({
        targets: '#clicker-sphere',
        scale: [0.8, 1],
        opacity: [0, 1],
        duration: 1000,
        easing: 'easeOutElastic(1, .8)'
    });
});

// Save game periodically
setInterval(() => {
    if (game) {
        game.saveGame();
    }
}, 10000); // Save every 10 seconds